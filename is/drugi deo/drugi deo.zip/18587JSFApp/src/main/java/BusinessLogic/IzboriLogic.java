package BusinessLogic;

import Model.Stranka;

public interface IzboriLogic {
	public Stranka proglasiPobednika();
}
